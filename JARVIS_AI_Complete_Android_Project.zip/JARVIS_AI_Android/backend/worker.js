const AGENT_INSTRUCTIONS = {
  General: "You are JARVIS, a helpful, precise personal AI assistant. Address the user respectfully. Be honest about your capabilities.",
  Developer: "You are JARVIS Developer, an expert programming tutor and software development assistant. Explain steps clearly and never claim code was tested unless it was.",
  Researcher: "You are JARVIS Researcher. Separate verified facts from uncertainty. Be concise and explain what needs checking.",
  Learning: "You are JARVIS Learning, a patient tutor. Teach step by step and adapt explanations to the learner.",
  Planner: "You are JARVIS Planner. Break goals into practical, ordered tasks with clear deliverables."
};

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: cors });
    }
    if (new URL(request.url).pathname !== "/chat") {
      return json({ error: "Not found. Use POST /chat." }, 404, cors);
    }
    if (request.method !== "POST") return json({ error: "POST required." }, 405, cors);

    try {
      const body = await request.json();
      const message = String(body.message || "").trim();
      const provider = String(body.provider || "groq").toLowerCase();
      const agent = String(body.agent || "General");
      const history = Array.isArray(body.history) ? body.history.slice(-12) : [];

      if (!message) return json({ error: "Message is required." }, 400, cors);
      if (message.length > 12000) return json({ error: "Message is too long." }, 413, cors);

      const system = AGENT_INSTRUCTIONS[agent] || AGENT_INSTRUCTIONS.General;
      let reply;

      if (provider === "groq") {
        if (!env.GROQ_API_KEY) return json({ error: "GROQ_API_KEY is not configured in Worker secrets." }, 503, cors);
        const messages = [{ role: "system", content: system }];
        for (const item of history) {
          if (["user", "assistant"].includes(item.role) && typeof item.content === "string") {
            messages.push({ role: item.role, content: item.content.slice(0, 6000) });
          }
        }
        messages.push({ role: "user", content: message });
        const upstream = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${env.GROQ_API_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model: env.GROQ_MODEL || "llama-3.3-70b-versatile",
            messages,
            temperature: 0.6,
            max_tokens: 1200
          })
        });
        const data = await upstream.json();
        if (!upstream.ok) return json({ error: data.error?.message || "Groq request failed." }, upstream.status, cors);
        reply = data.choices?.[0]?.message?.content;
      } else if (provider === "gemini") {
        if (!env.GEMINI_API_KEY) return json({ error: "GEMINI_API_KEY is not configured in Worker secrets." }, 503, cors);
        const contents = [];
        for (const item of history) {
          if (["user", "assistant"].includes(item.role) && typeof item.content === "string") {
            contents.push({
              role: item.role === "assistant" ? "model" : "user",
              parts: [{ text: item.content.slice(0, 6000) }]
            });
          }
        }
        contents.push({ role: "user", parts: [{ text: `${system}\n\nUser request: ${message}` }] });
        const model = env.GEMINI_MODEL || "gemini-2.0-flash";
        const upstream = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${env.GEMINI_API_KEY}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents,
              generationConfig: { temperature: 0.6, maxOutputTokens: 1200 }
            })
          }
        );
        const data = await upstream.json();
        if (!upstream.ok) return json({ error: data.error?.message || "Gemini request failed." }, upstream.status, cors);
        reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("");
      } else {
        return json({ error: "Unsupported provider. Choose Groq or Gemini." }, 400, cors);
      }

      return json({ reply: reply || "I could not generate a response." }, 200, cors);
    } catch (error) {
      return json({ error: "Invalid request or backend failure." }, 500, cors);
    }
  }
};

function json(data, status, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...headers }
  });
}
