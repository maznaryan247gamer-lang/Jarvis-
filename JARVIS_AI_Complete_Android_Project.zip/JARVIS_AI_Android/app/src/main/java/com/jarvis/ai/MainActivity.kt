package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Gold = Color(0xFFFFC857)
private val Yellow = Color(0xFFFFC400)
private val Red = Color(0xFFFF3038)
private val Background = Color(0xFF08090C)
private val Panel = Color(0xFF151820)

data class ChatMessage(val role: String, val text: String)
enum class JarvisStatus { IDLE, LISTENING, THINKING, SPEAKING }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
private fun JarvisApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_preferences", 0) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf("CORE") }
    var provider by remember { mutableStateOf(prefs.getString("provider", "Groq") ?: "Groq") }
    var agent by remember { mutableStateOf("General") }
    var backendUrl by remember {
        mutableStateOf(prefs.getString("backend_url", BuildConfig.DEFAULT_BACKEND_URL) ?: BuildConfig.DEFAULT_BACKEND_URL)
    }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(JarvisStatus.IDLE) }
    var errorText by remember { mutableStateOf("") }
    var speakingEnabled by remember { mutableStateOf(true) }

    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            val saved = prefs.getString("chat_history", null)
            if (saved != null) {
                runCatching {
                    val arr = JSONArray(saved)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        add(ChatMessage(obj.optString("role", "assistant"), obj.optString("text", "")))
                    }
                }
            }
            if (isEmpty()) add(ChatMessage("assistant", "Hello sir. Systems online. JARVIS is ready."))
        }
    }

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        val engine = TextToSpeech(context) { result ->
            if (result == TextToSpeech.SUCCESS) {
                tts?.language = Locale.UK
                tts?.setSpeechRate(0.94f)
                tts?.setPitch(0.88f)
            }
        }
        tts = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            tts = null
        }
    }

    LaunchedEffect(messages.size) {
        val arr = JSONArray()
        messages.takeLast(80).forEach {
            arr.put(JSONObject().put("role", it.role).put("text", it.text))
        }
        prefs.edit().putString("chat_history", arr.toString()).apply()
    }

    fun speak(text: String) {
        if (!speakingEnabled) return
        status = JarvisStatus.SPEAKING
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
        scope.launch {
            kotlinx.coroutines.delay((text.length * 45L).coerceIn(1200L, 9000L))
            if (status == JarvisStatus.SPEAKING) status = JarvisStatus.IDLE
        }
    }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }
    DisposableEffect(speechRecognizer) {
        onDispose { speechRecognizer?.destroy() }
    }

    fun startListening() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            errorText = "Speech recognition is not available on this device."
            return
        }
        status = JarvisStatus.LISTENING
        errorText = ""
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status = JarvisStatus.THINKING }
            override fun onError(error: Int) {
                status = JarvisStatus.IDLE
                errorText = "I couldn't hear that. Please try again."
            }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) input = spoken
                status = JarvisStatus.IDLE
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.UK.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        recognizer.startListening(intent)
    }

    val microphonePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening() else errorText = "Microphone permission was not granted."
    }

    fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty()) return
        input = ""
        messages.add(ChatMessage("user", prompt))
        status = JarvisStatus.THINKING
        errorText = ""
        scope.launch {
            val answer = withContext(Dispatchers.IO) {
                requestJarvisReply(
                    endpoint = backendUrl.trim(),
                    provider = provider,
                    agent = agent,
                    prompt = prompt,
                    history = messages.toList().dropLast(1).takeLast(12)
                )
            }
            messages.add(ChatMessage("assistant", answer))
            status = JarvisStatus.IDLE
            speak(answer)
        }
    }

    val pulse = rememberInfiniteTransition(label = "jarvis-pulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 0.97f, targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "pulse"
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Yellow, secondary = Gold, background = Background,
        surface = Panel, onPrimary = Color.Black, onBackground = Color.White,
        onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Background).padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("J.A.R.V.I.S. AI", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                    Text("STARK-INSPIRED PERSONAL INTELLIGENCE", color = Color.Gray, fontSize = 9.sp, letterSpacing = 1.4.sp)
                }
                Surface(color = Red, shape = CircleShape) {
                    Text("ONLINE", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(14.dp))

            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(148.dp).scale(pulseScale)
                        .background(Brush.radialGradient(listOf(Red.copy(alpha = 0.22f), Color.Transparent)), CircleShape)
                        .border(2.dp, if (status == JarvisStatus.THINKING) Gold else Red, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("J", color = Gold, fontSize = 65.sp, fontWeight = FontWeight.Black)
                        Text("AI CORE", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                when (status) {
                    JarvisStatus.IDLE -> "SYSTEM READY"
                    JarvisStatus.LISTENING -> "LISTENING..."
                    JarvisStatus.THINKING -> "PROCESSING..."
                    JarvisStatus.SPEAKING -> "SPEAKING..."
                },
                Modifier.fillMaxWidth(), color = Gold, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, letterSpacing = 2.sp, fontSize = 12.sp
            )

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("CORE", "CHAT", "CREATOR", "AGENTS", "SETTINGS").forEach { tab ->
                    FilterChip(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        label = { Text(tab, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Yellow,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            when (selectedTab) {
                "SETTINGS" -> {
                    Column(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                        Text("INTELLIGENCE SETTINGS", color = Gold, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("AI provider", color = Color.LightGray)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Groq", "Gemini").forEach { option ->
                                FilterChip(
                                    selected = provider == option,
                                    onClick = {
                                        provider = option
                                        prefs.edit().putString("provider", option).apply()
                                    },
                                    label = { Text(option) }
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Secure backend URL", color = Color.LightGray)
                        OutlinedTextField(
                            value = backendUrl,
                            onValueChange = { backendUrl = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("https://your-worker.workers.dev/chat") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            prefs.edit().putString("backend_url", backendUrl.trim()).apply()
                            errorText = "Backend address saved on this phone."
                        }) { Text("SAVE SETTINGS") }
                        Text("API keys belong on the backend, never inside the APK.", color = Gold, fontSize = 12.sp)
                        Text("Voice responses: ${if (speakingEnabled) "ON" else "OFF"}", color = Color.LightGray)
                        Switch(checked = speakingEnabled, onCheckedChange = { speakingEnabled = it })
                        OutlinedButton(onClick = {
                            messages.clear()
                            messages.add(ChatMessage("assistant", "Conversation cleared. Ready for a new task."))
                        }) { Text("CLEAR CHAT MEMORY") }
                    }
                }
                "AGENTS" -> {
                    Column(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                        Text("SPECIALISED AGENTS", color = Gold, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Text("Choose an agent, then send a request in Chat.", color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        listOf("General", "Developer", "Researcher", "Learning", "Planner").forEach { item ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                    .background(if (agent == item) Color(0xFF30303A) else Color(0xFF1B1D24), RoundedCornerShape(10.dp))
                                    .clickable { agent = item }.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(item, color = Color.White, fontWeight = FontWeight.SemiBold)
                                if (agent == item) Text("SELECTED", color = Gold, fontSize = 10.sp)
                            }
                        }
                        Text("Agents use the same AI backend with different task instructions.", color = Color.Gray, fontSize = 11.sp)
                    }
                }
                "CREATOR" -> {
                    Column(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                        Text("CREATOR WORKSPACE", color = Gold, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Text("Choose the Developer agent to plan apps, explain code, debug errors and design project structures.", color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { agent = "Developer"; selectedTab = "CHAT"; input = "Help me plan and build an Android application step by step." }) {
                            Text("START APP DEVELOPMENT")
                        }
                        OutlinedButton(onClick = { selectedTab = "CHAT"; input = "Help me understand and fix this code: " }) {
                            Text("DEBUG CODE")
                        }
                    }
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(if (selectedTab == "CORE") "COMMAND CENTRE" else "CONVERSATION", color = Gold, fontWeight = FontWeight.Black, fontSize = 16.sp)
                            Text("Provider: $provider  •  Agent: $agent", color = Color.Gray, fontSize = 10.sp)
                        }
                        items(messages) { message ->
                            val isAssistant = message.role == "assistant"
                            Column(
                                Modifier.fillMaxWidth(),
                                horizontalAlignment = if (isAssistant) Alignment.Start else Alignment.End
                            ) {
                                Text(if (isAssistant) "JARVIS" else "YOU", color = if (isAssistant) Gold else Color.LightGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Surface(
                                    color = if (isAssistant) Color(0xFF222A35) else Color(0xFF653036),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(message.text, Modifier.padding(10.dp), color = Color.White, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            if (errorText.isNotBlank()) {
                Text(errorText, color = Gold, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
            }

            if (selectedTab != "SETTINGS" && selectedTab != "AGENTS") {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                startListening()
                            } else {
                                microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 13.dp)
                    ) { Text("🎙", fontSize = 17.sp) }
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask JARVIS...", fontSize = 13.sp) },
                        singleLine = true
                    )
                    Button(onClick = { sendMessage() }, contentPadding = PaddingValues(horizontal = 13.dp, vertical = 16.dp)) {
                        Text("SEND", fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("JARVIS AI • PHONE-ONLY PROJECT • PRIVATE BUILD", Modifier.fillMaxWidth(), color = Color.Gray, fontSize = 9.sp, textAlign = TextAlign.Center)
        }
    }
}

private fun requestJarvisReply(
    endpoint: String,
    provider: String,
    agent: String,
    prompt: String,
    history: List<ChatMessage>
): String {
    if (endpoint.contains("YOUR-WORKER")) {
        return "The interface is working, sir. To activate real AI, deploy the secure backend in the backend folder, then paste its /chat URL into Settings."
    }
    return try {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val historyArray = JSONArray()
        history.forEach {
            historyArray.put(JSONObject().put("role", it.role).put("content", it.text))
        }
        val body = JSONObject()
            .put("provider", provider.lowercase(Locale.ROOT))
            .put("agent", agent)
            .put("message", prompt)
            .put("history", historyArray)
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        val json = JSONObject(response)
        if (code !in 200..299) {
            "Backend error ($code): ${json.optString("error", "Please check your backend settings.")}"
        } else {
            json.optString("reply").ifBlank { "I received an empty response, sir." }
        }
    } catch (e: Exception) {
        "I couldn't reach the AI service. Please check your internet connection and backend URL. Details: ${e.localizedMessage ?: "connection error"}"
    }
}
